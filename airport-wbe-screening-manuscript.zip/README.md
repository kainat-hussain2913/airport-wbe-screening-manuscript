# Airport passenger screening and aircraft wastewater surveillance — model code and results

Supplementary material for *Aircraft Wastewater Surveillance for Airport Biosecurity:
When Does Early Warning Deliver Value?*

This repository contains the decision-analytic model, its parameter tables, every
result file underlying the figures and tables in the manuscript, and the
supplementary methods document. It is the material referred to in the manuscript's
Data and code availability statement and its List of supplementary items.

`MANIFEST.md` maps each item promised in the manuscript to the file that provides
it, and states the two items that are not included.

## Contents

```
*.py                      model, analyses, figure scripts — run from this directory
results/                  every CSV, JSON and .npz output reported in the manuscript
results/national/         Australia and United States national-scale configurations and outputs
figures/                  Figures 1-5 (PNG and, where produced, SVG)
supplementary/            Supplementary Material document and its two source workbooks
logs/                     run logs for the three long-running analyses
CONFIGURATION.md          the configuration every analysis was run under
VALIDATION.md             engine validation, reproduction and stream-identity checks
CHECKSUMS.txt             SHA-256 (first 16 hex) of every file here
requirements.txt          pinned dependency versions
```

## Model

The model is deterministic: an importation-screening layer feeds missed infected
arrivals into an SIR transmission model of a downstream catchment population, and a
societal cost function prices the resulting burden over a 365-day horizon.

- `engine.py` — screening layer, SIR integration (RK4, daily step), cost function
- `parameters.py` — pathogen, diagnostic, economic and scenario parameters with sources
- `icu_parameters.py` — ICU admission fractions, lengths of stay and the incremental daily rate
- `runners.py` — scenario runners shared by the portfolio and national-scale analyses

Probabilistic analysis draws 10,000 iterations per pathogen from distributions
moment-matched to the cited parameter ranges, under a fixed base seed of 20260811
offset by pathogen index. `CONFIGURATION.md` states every seed.

## Reproducing the results

```
pip install -r requirements.txt

python3 run_master.py                   # deterministic strategy grid              ~3 min
python3 vsl_sensitivity.py              # value-of-statistical-life anchors        ~1 min
python3 countermeasure_sensitivity.py   # 4x3x3 sweep plus no-countermeasure rows  ~4 min
python3 decision_surface.py && python3 plot_decision_surface.py     # Figure 3
python3 psa_icu.py                      # probabilistic sensitivity analysis      ~15 min
python3 psa_icu.py --no-cost-draws --out-prefix psa_icu_midpointcost_control      ~15 min
python3 psa_convergence_icu.py --with-measles    # convergence and decomposition  ~12 min
python3 make_fig4.py                    # Figure 4, plotted from the saved CSV
python3 wbe_threshold_sweep_icu.py      # WBE gate parameter sweep
python3 plot_wbe_decision_threshold_icu.py       # Figure 5
python3 false_positive_breakeven.py     # false-positive follow-up breakeven
python3 reconciliation_10k.py           # lead-time value analysis and portfolios
python3 wbe_idealised_limit.py          # WBE gate at its idealised limiting case
```

Every script resolves imports relative to its own directory; there are no absolute
paths. Scripts write into `results/` and `figures/`, overwriting the copies
distributed here.

## Scope and limitations

The limitations of the analysis are stated in the manuscript and are not repeated
here. Two points bear on the code specifically:

- The four aircraft-WBE performance parameters — detection probability, fielded
  false-positive rate, cost per aircraft sample and achievable follow-up coverage —
  are swept over bounding ranges, not estimated. Nothing in `results/wbe_sweep/`
  should be read as a measurement of real-world aircraft WBE performance.
- The proprietary simulator referred to in the manuscript's Software and
  reproducibility section is not part of this repository and is not required by it.
  No numerical result reported in the manuscript is drawn from it.

## Funding and competing interests

This work was supported by Avicena Systems Limited. The sponsoring organisation has
a commercial interest in one of the evaluated surveillance platforms. The competing
interest and the methodological safeguards applied in response to it are declared in
the manuscript.
